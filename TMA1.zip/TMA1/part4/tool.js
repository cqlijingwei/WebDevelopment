
$(document).ready(function (){
  $('#tool1').click(function () {
    $('#ajax-content').load('https://cqlijingwei.github.io/professional%20experience/web%20development/part4/tool1/');
  });
  $('#tool2').click(function () {
    $('#ajax-content').load('https://cqlijingwei.github.io/professional%20experience/web%20development/part4/tool2/');
  });
  $('#tool3').click(function() {
    $('#ajax-content').load('https://cqlijingwei.github.io/professional%20experience/web%20development/part4/tool3/');
  });
}); 