var DATA = [
    {
      question: "which of the following can be a tag in XML?",
      answers: {
        a: "player",
        b: "basketball",
        c: "salary",
        d: "all of the above"
      },
      correctAnswer: "d"
    },
    {
      question: "Which of the following language is NOT used in client-side of ajax application?",
      answers: {
        a: "HTML5",
        b: "CSS3",
        c: "Python",
        d: "JavaScript"
      },
      correctAnswer: "c"
    },
    {
      question: "Which of the following is NOT the feature of ajax-enabled forms?",
      answers: {
        a: "Entries are validated individually.",
        b: "Dynamic response is made when the user enters data.",
        c: "Asynchronous allows the user to address invalid entries quickly.",
        d: "Only synchronous requests could be used to fill some fields."
      },
      correctAnswer: "d"
    }
  ];