var DATA = [
    {
      question: "What is the full name of URL?",
      answers: {
        a: "Uniform Regular Length",
        b: "Uniform Resource Identifiers",
        c: "Uniform Resource Locator"
      },
      correctAnswer: "c"
    },
    {
      question: "Which of the following is NOT a tag in html?",
      answers: {
        a: "html",
        b: "body",
        c: "love"
      },
      correctAnswer: "c"
    },
    {
      question: "Which of the following is NOT a new input type in html?",
      answers: {
        a: "color",
        b: "date",
        c: "file",
        d: "abbreviation"
      },
      correctAnswer: "d"
    }
  ];