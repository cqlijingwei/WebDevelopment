var DATA = [
    {
      question: "Which of the following is a method in JavaScript?",
      answers: {
        a: "output",
        b: "println",
        c: "writeln"
      },
      correctAnswer: "c"
    },
    {
      question: "What is the output of variable x='2'+5?",
      answers: {
        a: "7",
        b: "2+5",
        c: "25"
      },
      correctAnswer: "c"
    },
    {
      question: "Where is coordinate origin by default in Canvas?",
      answers: {
        a: "leftup corner",
        b: "rightup corner",
        c: "leftdown corner",
        d: "rightdown corner"
      },
      correctAnswer: "a"
    }
  ];