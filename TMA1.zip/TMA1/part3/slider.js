var slideIndex = 1;
var slide = document.getElementById('slides');
var ctx = slide.getContext('2d');
var prev = document.getElementById('prevSlide');
var next = document.getElementById('nextSlide');
showSlides(slideIndex);

var photos=([
  {"src": "photo1.jpg", "name": "Playground in Halifax, Nova Scotia"},
  {"src": "photo2.jpg", "name": "Back Side of Giant Piano in Sydney, Nova Scotia"},
  {"src": "photo3.jpg", "name": "Front Side of Giant Piano in Sydney, Nova Scotia"},
  {"src": "photo4.jpg", "name": "Peggys Cove in Halifax, Nova Scotia(Dark)"},
  {"src": "photo5.jpg", "name": "Peggys Cove in Halifax, Nova Scotia(Light)"},
  {"src": "photo6.jpg", "name": "Peggys Cove in Halifax, Nova Scotia(Left)"},
  {"src": "photo7.jpg", "name": "Trinity College Church in Toronto, Ontario"},
  {"src": "photo8.jpg", "name": "Varsity Centre in Toronto, Ontario(Close Shot)"},
  {"src": "photo9.jpg", "name": "Varsity Centre in Toronto, Ontario(Condo View)"},
  {"src": "photo10.jpg", "name": "CN Tower View from UofT in Toronto, Ontario"},
  {"src": "photo11.jpeg", "name": "University College View from King's Circle in Toronto, Ontario"},
  {"src": "photo12.jpeg", "name": "Maple Tree in UofT in Toronto, Ontario"},
  {"src": "photo13.jpeg", "name": "View from King's Circle in UofT in Toronto, Ontario"},
  {"src": "photo14.jpeg", "name": "Blue Sky View from Upper Middle Rd E in Oakville, Ontario"},
  {"src": "photo15.jpeg", "name": "School near Brookmede Park in Mississauga, Ontario"},
  {"src": "photo16.jpeg", "name": "View from Mountain in Brookmede Park in Mississauga, Ontario"},
  {"src": "photo17.jpeg", "name": "Gaint Duck by the Lakeshore in Toronto, Ontario"},
  {"src": "photo18.jpeg", "name": "Gaint Duck and Duckling by the Lakeshore in Toronto, Ontario"},
  {"src": "photo19.jpeg", "name": "CN Tower View from Robarts Library in Toronto, Ontario"},
  {"src": "photo20.jpeg", "name": "Seascape along the Way from Swartz Bay to Tsawwassen, British Columbia"}
]);

function showSlides(n) {
  var i;
  if (n > photos.length ) {slideIndex = 1}
  if (n<1) {slideIndex = photos.length}
  loadImage(n-1);
}

function loadImage(i) {
  ctx.clearRect(0,0,slide.width, slide.height);
  var img1 = new Image();
  img1.src = photos[i].src;

  img1.onload = function() {
    ctx.clearRect(0,0,slide.width,slide.height);
    ctx.drawImage(img1, 0,0, slide.width, slide.height);
    ctx.fillStyle = "rgba(200, 0, 0, 0.5)";
    ctx.fillRect(0,0,500,500);
    ctx.font = "15pt Lato";
    ctx.fillStyle = "white";
    ctx.textAlign = "center";
    ctx.fillText(photos[i].name, slide.width/2, slide.height-20);
  }
}

$(prev).click = plusSlides(-1);
$(next).click = plusSlides(1);

function plusSlides(n) {
  showSlides(slideIndex += n);
}