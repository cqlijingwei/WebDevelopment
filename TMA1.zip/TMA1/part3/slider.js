var slideIndex = 1;
var slide = document.getElementById('slides');
var ctx = slide.getContext('2d');
var prev = document.getElementById('prevSlide');
var next = document.getElementById('nextSlide');
var textColor = document.getElementById('textColor');
var play = document.getElementById('play');
var sequence = document.getElementById('sequence');
var playShow=null;
var playShowEffect=null;
var effect = document.getElementById('effect');
var indexFade=0.00;
var delta = 0;
var heightSlide = slide.height;

var photos=([
  {"src": "../shared/photo1.jpg", "name": "Playground in Halifax, Nova Scotia"},
  {"src": "../shared/photo2.jpg", "name": "Back Side of Giant Piano in Sydney, Nova Scotia"},
  {"src": "../shared/photo3.jpg", "name": "Front Side of Giant Piano in Sydney, Nova Scotia"},
  {"src": "../shared/photo4.jpg", "name": "Peggys Cove in Halifax, Nova Scotia(Dark)"},
  {"src": "../shared/photo5.jpg", "name": "Peggys Cove in Halifax, Nova Scotia(Light)"},
  {"src": "../shared/photo6.jpg", "name": "Peggys Cove in Halifax, Nova Scotia(Left)"},
  {"src": "../shared/photo7.jpg", "name": "Trinity College Church in Toronto, Ontario"},
  {"src": "../shared/photo8.jpg", "name": "Varsity Centre in Toronto, Ontario(Close Shot)"},
  {"src": "../shared/photo9.jpg", "name": "Varsity Centre in Toronto, Ontario(Condo View)"},
  {"src": "../shared/photo10.jpg", "name": "CN Tower View from UofT in Toronto, Ontario"},
  {"src": "../shared/photo11.jpeg", "name": "University College View from King's Circle in Toronto, Ontario"},
  {"src": "../shared/photo12.jpeg", "name": "Maple Tree in UofT in Toronto, Ontario"},
  {"src": "../shared/photo13.jpeg", "name": "View from King's Circle in UofT in Toronto, Ontario"},
  {"src": "../shared/photo14.jpeg", "name": "Blue Sky View from Upper Middle Rd E in Oakville, Ontario"},
  {"src": "../shared/photo15.jpeg", "name": "School near Brookmede Park in Mississauga, Ontario"},
  {"src": "../shared/photo16.jpeg", "name": "View from Mountain in Brookmede Park in Mississauga, Ontario"},
  {"src": "../shared/photo17.jpeg", "name": "Gaint Duck by the Lakeshore in Toronto, Ontario"},
  {"src": "../shared/photo18.jpeg", "name": "Gaint Duck and Duckling by the Lakeshore in Toronto, Ontario"},
  {"src": "../shared/photo19.jpeg", "name": "CN Tower View from Robarts Library in Toronto, Ontario"},
  {"src": "../shared/photo20.jpeg", "name": "Seascape along the Way from Swartz Bay to Tsawwassen, British Columbia"}
]);

showSlides(slideIndex);

function showSlides(n) {
  if (n > photos.length ) {slideIndex = 1}
  if (n<1) {slideIndex = photos.length}
  loadImage(slideIndex-1);
}

function loadImage(i) {
  clearInterval(playShowEffect);
  ctx.clearRect(0,0,slide.width, slide.height);
  switch(effect.value) {
    case 'no':
        displayImage(i);
        break;
    case 'slide':
        playShowEffect = setInterval(function(){displayImage(i)},15);
        break;
    case 'fade':
        playShowEffect = setInterval(function(){displayImage(i)},15);
        break;
  }
}

function displayImage(i) {
  if (effect.value == 'fade') {
    indexFade+=0.01;
    ctx.globalAlpha = indexFade;
    ctx.imageSmoothingEnabled = true;
  }

  if (effect.value == 'slide') {
    heightSlide = slide.height/100*delta;
    delta++;
  }
  else
    heightSlide=slide.height;

  if (i > photos.length - 1) {i = 0;slideIndex=1}
  if (i<0) {i=photos.length-1;slideIndex=photos.length}
  var img1 = new Image();
  img1.src = photos[i].src;

  img1.onload = function() {
    ctx.clearRect(0,0,slide.width, slide.height);
    ctx.drawImage(img1, 0, 0, slide.width, heightSlide);
    ctx.font = "16pt Lato";
    ctx.textAlign = "center";
    ctx.fillStyle = textColor.value;
    ctx.fillText(photos[i].name+" ( photo "+slideIndex+" / "+photos.length+" )", slide.width/2, 20);
  }

  if (effectCondition()) {
    clearInterval(playShowEffect);
  }
}

function effectCondition() {
  if (effect.value=="no")
    return true;

  if (effect.value=="slide" && heightSlide>=slide.height){
    delta = 0;
    return true;
  }

  if (effect.value=="fade" && indexFade>=1.00){
    indexFade=0.00;
    return true;
  }
}

textColor.onchange = function() {
  loadImage(slideIndex-1);
}

$(document).ready(function (){
  $('#prevSlide').click(function () {
    if (sequence.value == "sequential")
      plusSlides(-1);
  });
  $('#nextSlide').click(function () {
    if (sequence.value == "sequential")
      plusSlides(1);
  });
  $('#play').click(function() {
    if (play.getAttribute('src')=='../shared/startButton.png') {
      play.setAttribute('src', '../shared/stopButton.png');
      playShow = setInterval(function(){playByMode()},3000);
    }
    else {
      play.setAttribute('src','../shared/startButton.png');
      clearInterval(playShow);
    }
  });
}); 

function playByMode() {
  if (sequence.value == "sequential")
    slideIndex++;
  else
    slideIndex = Math.floor(Math.random() * 20) + 1;
  loadImage(slideIndex-1);
}

function plusSlides(n) {
  slideIndex += n;
  loadImage(slideIndex-1);
}