<?php
session_start();
$_SESSION['producelist']="";
$_SESSION['quatity']="";
header("location:cart_null.php");
?>