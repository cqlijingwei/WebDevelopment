<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>Untitled document</title>
<link rel="stylesheet" type="text/css" href="css/font.css">
<style type="text/css">
<!--
body {
	margin-top: 0px;
	margin-left: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>
<script type="text/javascript">
<!--
function MM_popupMsg(msg) { //v1.0
  if(confirm(msg))
     window.parent.location="index.php";
   else
     return false;
}
//-->
</script>
</head>
<body>
<table width="1003" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="1003" height="90" align="right" background="images/banner.gif"><a href="#" style="color:#FFFFFF; font-size:16px; padding-right:10px;" onclick="return MM_popupMsg('Do you want to log out?');">Sign out</a></td>
  </tr>
</table>
</body>
</html>
