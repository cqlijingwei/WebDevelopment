<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>E-commerce platform network background</title>
<link rel="stylesheet" type="text/css" href="css/font.css">
</head>
<body topmargin="0" leftmargin="0" bottommargin="0" class="scrollbar">
<table width="1003" align="center" cellpadding="1" cellspacing="0" bordercolor="#CCCCCC" bgcolor="#999999">
  <tr>
    <td><table width="1003" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="90" bgcolor="#FFFFFF"><div align="center">
            <iframe frameBorder=0 id=top name=top scrolling=no src="top.php" 
     style="height: 90px; visibility: inherit; width: 1003px; z-index: 3"> </iframe>
        </div></td>
      </tr>
    </table>
      <table width="1003" height="460" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="212" height="460" valign="top" bgcolor="#FFCF60" id="lt" style="display:"><div align="center">
              <iframe frameBorder=0 id=left name=left src="left.php" 
      style="height: 100%; visibility: inherit; width: 212px; z-index: 2"> </iframe>
          </div></td>
          <td width="13" height="460" background="images/bg_line.gif"><div align="center"></div></td>
          <td width="778" height="460" bgcolor="#FFFFFF" id="mn"><div align="center">
              <iframe frameBorder=0 id=main name=main scrolling=yes src="lookdd.php" 
      style="height: 100%; visibility: inherit; width: 778px; z-index: 1"> </iframe>
          </div></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>
