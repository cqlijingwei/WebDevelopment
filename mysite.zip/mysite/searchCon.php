<div class="col-xs-12 col-md-3 pull-right col-sm-6">
						<div class="head-search ">
							<div>
								<form action="search_result.php" method="post" class="form-inline form-search">

									<input name="searchword" maxlength="100" class="search-query"
										type="search" placeholder="Please Input......">
									<input value="Search" type="submit">
								</form>
							</div>
						</div>
					</div>