var exist = false;

$('#signIn').click(function() {
	exist = true;
	noEmpty();
	$('input[name$="username"]').keyup(function() {
		ValidateUsername(username, exist);
	});
});

$('#signUp').click(function() {
	exist=false;
	noEmpty();
	$('input[name$="username"]').keyup(function() {
		ValidateUsername(username, exist);
	});
});

function noEmpty() {
	if ($('input[name$="password"]').prop('value').length <= 0) {
		ShowError('Please fill in the password.');
		return false;
	} else if ($('input[name$="username"]').prop('value').length <= 0) {
		ShowError('Please fill in the username.');
		return false;
	}

	HideError();
	return true;
}

function ValidateUsername(username, exist) {
	$.get('login.php'),
		{'userExists':username},
		function(data) {
			if(exist && data == false) {
				ShowError('The username does not exist.');
			}
			else if(!exist && data == true) {
				ShowError('The username exists. Please try another one.');
			}
			else if((exist && data == true) || (!exist && data == false)) {
				HideError();
			}
			
			if($('input[name$="password"]').prop('value') == "")
				EnableLogin(false);
		});		
}